(function () {

    'use strict';

    angular.module('GitHubOwnerImageApp', [
        'GitHubOwnerImageApp.controllers',
        'GitHubOwnerImageApp.services',
        'ui.bootstrap'
    ]);

})();
